package sample;

import java.lang.Math;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.event.ActionEvent;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    @FXML
    public TextField T2,T3;
    public Label q1,q2;
    double d1,d2;
    char c1;
    @FXML
    public void click0() {T2.setText(T2.getText() + "0");}
    public void click1() {T2.setText(T2.getText() + "1");}
    public void click2() {T2.setText(T2.getText() + "2");}
    public void click3() {T2.setText(T2.getText() + "3");}
    public void click4() {T2.setText(T2.getText() + "4");}
    public void click5() {T2.setText(T2.getText() + "5");}
    public void click6() {T2.setText(T2.getText() + "6");}
    public void click7() {T2.setText(T2.getText() + "7");}
    public void click8() {T2.setText(T2.getText() + "8");}
    public void click9() {T2.setText(T2.getText() + "9");}
    public void dot() {T2.setText(T2.getText() + ".");}

    public void mclick0() {T3.setText(T3.getText() + "0");}
    public void mclick1() {T3.setText(T3.getText() + "1");}
    public void mclick2() {T3.setText(T3.getText() + "2");}
    public void mclick3() {T3.setText(T3.getText() + "3");}
    public void mclick4() {T3.setText(T3.getText() + "4");}
    public void mclick5() {T3.setText(T3.getText() + "5");}
    public void mclick6() {T3.setText(T3.getText() + "6");}
    public void mclick7() {T3.setText(T3.getText() + "7");}
    public void mclick8() {T3.setText(T3.getText() + "8");}
    public void mclick9() {T3.setText(T3.getText() + "9");}
    public void mdot() {T3.setText(T3.getText() + ".");}

    String checkstr = "";
    //----------------------- Basic functions like add,sub, main win -------------------------------------------------------
    public void add(){
        String h=(T2.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T2.getText());
        c1='+';T2.setText(T2.getText() + "+");
    }
    public void sub(){
        String h=(T2.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T2.getText());
        c1='-';T2.setText(T2.getText() + "-");
    }
    public void mul(){
        String h=(T2.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T2.getText());
        c1='*';T2.setText(T2.getText() + "*");
    }
    public void div(){
        String h=(T2.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T2.getText());
        c1='/';T2.setText(T2.getText() + "/");
    }
    public void del() {
        try {
            String s = T2.getText();
            T2.setText(s.substring(0, s.length() - 1));
        }catch(Exception e){
            System.out.println("");
        }
    }
    public void clean(){
        T2.setText("0");q1.setText("");
    }
    public void percent(){
        double a = Double.parseDouble(T2.getText());
        double b = a/100;
        q1.setText("percent("+T2.getText()+")"+" =");
        T2.setText(""+b);
    }
    public void fsqrt(){
        double a = Double.parseDouble(T2.getText());
        double b = Math.sqrt(a);
        q1.setText("√"+a+" =");
        T2.setText(""+b);
    }
    public void fnegate(){
        try {
            double a = Double.parseDouble(T2.getText());
            double b = -a;
            T2.setText("" + b);
        }catch (Exception e){
            System.out.println("");
        }
    }
    public void fxx(){
        double a = Double.parseDouble(T2.getText());
        double b = a*a;
        T2.setText(""+b);
    }
    public void fFact(){
        int i,f=1;
        int a = Integer.parseInt(T2.getText());
        for(i=1;i<=a;i++){
            f=f*i;
        }
        q1.setText(a+"! =");
        T2.setText(""+f);
    }

    public void equal(){
        String s1=T2.getText(),s2;
        double d3;
        switch(c1)
        {
            case '+':
                s2=s1.substring(s1.indexOf('+')+1);
                d2=Double.parseDouble(s2);
                d3=d1+d2;
                q1.setText(T2.getText()+"=");
                T2.setText(""+d3);
                break;
            case '-':
                s2=s1.substring(s1.indexOf('-')+1);
                d2=Double.parseDouble(s2);
                d3=d1-d2;
                q1.setText(T2.getText()+"=");
                T2.setText(""+d3);
                break;
            case '*':
                s2=s1.substring(s1.indexOf('*')+1);
                d2=Double.parseDouble(s2);
                d3=d1*d2;
                q1.setText(T2.getText()+"=");
                T2.setText(""+d3);
                break;
            case '/':
                s2=s1.substring(s1.indexOf('/')+1);
                d2=Double.parseDouble(s2);
                d3=d1/d2;
                q1.setText(T2.getText()+"=");
                T2.setText(""+d3);
                break;
        }
    }
    double mx;
//----------------------------- Maths function -------------------------------------------------------------------------
    public void sin(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.sin(a);
        q2.setText("sin("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void tan(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.tan(a);
        q2.setText("tan("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void cos(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.cos(a);
        q2.setText("cos("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void sec(){
        double a = Double.parseDouble(T3.getText());
        double b = 1/Math.cos(a);
        q2.setText("sec("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void cosec(){
        double a = Double.parseDouble(T3.getText());
        double b = 1/Math.sin(a);
        q2.setText("cosec("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void cot(){
        double a = Double.parseDouble(T3.getText());
        double b = 1/Math.tan(a);
        q2.setText("cot("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void degToRad(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.toRadians(a);
        q2.setText(a+"deg to rad=");
        T3.setText(""+b);
    }
    public void radToDeg(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.toDegrees(a);
        q2.setText(a+"rad to deg=");
        T3.setText(""+b);
    }
    public void exp(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.exp(a);
        q2.setText("exp"+a+" =");
        T3.setText(""+b);
    }
    public void invx(){
        double a = Double.parseDouble(T3.getText());
        double b = 1/a;
        T3.setText(""+b);
    }
    public void log(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.log10(a);
        q2.setText("log("+a+") =");
        T3.setText(""+b);
    }
    public void ln(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.log(a);
        q2.setText("ln("+a+") =");
        T3.setText(""+b);
    }
    public void sqrt(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.sqrt(a);
        q2.setText("√"+a+" =");
        T3.setText(""+b);
    }
    public void fact(){
        int i,f=1;
        int a = Integer.parseInt(T3.getText());
        for(i=1;i<=a;i++){
            f=f*i;
        }
        q2.setText(a+"! =");
        T3.setText(""+f);
    }
    public void mod(){
        double a = Double.parseDouble(T3.getText());
        if(a<0){
            double b = -a;
            T3.setText(""+b);
        }
        else{
            T3.setText(""+a);
        }
    }
    public void arcsin(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.asin(a);
        q2.setText("arc sin("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void arccos(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.acos(a);
        q2.setText("arc cos("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void arctan(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.atan(a);
        q2.setText("arc tan("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void arccosec(){
        double a = Double.parseDouble(T3.getText());
        double b = 1/Math.asin(a);
        q2.setText("arc cosec("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void arcsec(){
        double a = Double.parseDouble(T3.getText());
        double b = 1/Math.acos(a);
        q2.setText("arc sec("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void arccot(){
        double a = Double.parseDouble(T3.getText());
        double b = Math.atan(a);
        q2.setText("arc cot("+T3.getText()+")"+" =");
        T3.setText(""+b);
    }
    public void negate(){
        double a = Double.parseDouble(T3.getText());
        double b = -a;
        T3.setText(""+b);
    }
    public void xx(){
        double a = Double.parseDouble(T3.getText());
        double b = a*a;
        T3.setText(""+b);
    }
    public void xToY(){
        mx=Double.parseDouble(T3.getText());
        q2.setText(T3.getText()+"^");
        T3.setText("");
        c1 = 'X';
    }
    public void tenToX(){
        double a =Double.parseDouble(T3.getText());
        double b = Math.pow(10,a);
        q2.setText("10^"+a+" =");
        T3.setText(""+b);
    }
    public void mback(ActionEvent event){
        Pane4.setVisible(false);
        ((Stage)(((Button)event.getSource()).getScene().getWindow())).setWidth(445);
        ((Stage)(((Button)event.getSource()).getScene().getWindow())).setHeight(612);
        Pane2.setVisible(true);
    }


//------------------------------------ T3 ----- Pane4 ---------------------------------------------------------------------
public void madd(){
    String h=(T3.getText());
    if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
        equal();
    d1=Double.parseDouble(T3.getText());
    c1='+';T3.setText(T3.getText() + "+");
}
    public void msub(){
        String h=(T3.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T3.getText());
        c1='-';T3.setText(T3.getText() + "-");
    }
    public void mmul(){
        String h=(T3.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T3.getText());
        c1='*';T3.setText(T3.getText() + "*");
    }
    public void mdiv(){
        String h=(T3.getText());
        if(h.contains("+")||h.contains("*")||h.contains("-")||h.contains("/"))
            equal();
        d1=Double.parseDouble(T3.getText());
        c1='/';T3.setText(T3.getText() + "/");
    }
    public void mdel() {
        String s = T3.getText();
        T3.setText(s.substring(0, s.length() - 1));
    }
    public void mclean(){
        T3.setText("");q2.setText("");
    }
    public void mequal(){
        String s1=T3.getText(),s2;
        double d3;
        switch(c1)
        {
            case '+':
                s2=s1.substring(s1.indexOf('+')+1);
                d2=Double.parseDouble(s2);
                d3=d1+d2;
                q2.setText(T3.getText()+"=");
                T3.setText(""+d3);
                break;
            case '-':
                s2=s1.substring(s1.indexOf('-')+1);
                d2=Double.parseDouble(s2);
                d3=d1-d2;
                q2.setText(T3.getText()+"=");
                T3.setText(""+d3);
                break;
            case '*':
                s2=s1.substring(s1.indexOf('*')+1);
                d2=Double.parseDouble(s2);
                d3=d1*d2;
                q2.setText(T3.getText()+"=");
                T3.setText(""+d3);
                break;
            case '/':
                s2=s1.substring(s1.indexOf('/')+1);
                d2=Double.parseDouble(s2);
                d3=d1/d2;
                q2.setText(T3.getText()+"=");
                T3.setText(""+d3);
                break;
            case 'X':
                double my = Double.parseDouble(T3.getText());
                double res = Math.pow(mx,my);
                T3.setText(""+res);
                q2.setText(q2.getText()+my+" =");
                c1 = 'v';
                break;
        }
    }
//-------------------------------------------------------------------------------------------------------------------------

    @FXML
    TextField M1;
    public Label M2;
    @FXML
    Pane Pane1,Pane2,Pane3,Pane4,Pane5,Pane7;
    public void change(){
        Pane2.setVisible(true);
        Pane1.setVisible(false);
    }
    public void back(){
        Pane2.setVisible(false);
        Pane1.setVisible(true);

    }
    //----------------------------------------------------------------------------------------------------------------------
//----------------------- Setting things for length win ----------------------------------------------------------------
    public ComboBox<String> cmb1,cmb2;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        cmb1.setItems(FXCollections.observableArrayList("Metres", "Centimetres", "Feet","Kilometres","Millimetres","Miles"));
        cmb2.setItems(FXCollections.observableArrayList("Metres", "Centimetres", "Feet","Kilometres","Millimetres","Miles"));
    }

    public void lengthWin(){
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Metres", "Centimetres", "Feet","Kilometres","Millimetres","Miles"));
        cmb2.setItems(FXCollections.observableArrayList("Metres", "Centimetres", "Feet","Kilometres","Millimetres","Miles"));
        checkstr = "Length";
    }
    public void fun(ActionEvent e){
        M1.setText((M1.getText())+((Button)e.getSource()).getText());
    }
    public void back1(){
        Pane2.setVisible(true);
        Pane1.setVisible(false);
        Pane3.setVisible(false);}

    public void del1() {
        String s = M1.getText();
        M1.setText(s.substring(0, s.length() - 1));}
    public void lenClear(){
        M1.setText("");
    }
    //----------------------------- Code for length conversion fns ---------------------------------------------------------
    public double lengthFn(String in,String out,double v){
        switch(in){
            case "Metres":
                switch (out) {
                    case "Millimetres":
                        return v * 1000;
                    case "Centimetres":
                        return v * 100;
                    case "Miles":
                        return v * 0.000621;
                    case "Kilometres":
                        return v * 0.001;
                    case "Feet":
                        return v * 3.28084;
                }

            case "Millimetres":
                switch (out) {
                    case "Metres":
                        return v * 0.001;
                    case "Centimetres":
                        return v * 0.1;
                    case "Miles":
                        return v * 0.000000621371192;
                    case "Kilometres":
                        return v * 0.000001;
                    case "Feet":
                        return v * 0.003281;
                }

            case "Centimetres":
                switch (out) {
                    case "Metres":
                        return v * 0.01;
                    case "Millimetres":
                        return v * 10;
                    case "Miles":
                        return v * 0.000006;
                    case "Kilometres":
                        return v * 0.00001;
                    case "Feet":
                        return v * 0.032808;
                }

            case "Miles":
                switch (out) {
                    case "Metres":
                        return v * 1609.344;
                    case "Millimetres":
                        return v * 1609344;
                    case "Centimetres":
                        return v * 160934.4;
                    case "Kilometres":
                        return v * 1.609344;
                    case "Feet":
                        return v * 5280;
                }

            case "Kilometres":
                switch (out) {
                    case "Metres":
                        return v * 1000;
                    case "Millimetres":
                        return v * 1000000;
                    case "Centimetres":
                        return v * 100000;
                    case "Miles":
                        return v * 0.621371;
                    case "Feet":
                        return v * 3280.84;
                }
            case "Feet":
                switch (out) {
                    case "Metres":
                        return v * 0.3048;
                    case "Millimetres":
                        return v * 304.8;
                    case "Centimetres":
                        return v * 30.48;
                    case "Miles":
                        return v * 0.000189;
                    case "Kilometres":
                        return v * 0.000305;
                }
        }
        return 1;
    }
    // ------------------------------ Setting up for weight conversion -----------------------------------------------------
    public void weightWin() {
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Grams","Kilograms","Milligrams","Tonne","Pounds","Ounces"));
        cmb2.setItems(FXCollections.observableArrayList("Grams","Kilograms","Milligrams","Tonne","Pounds","Ounces"));
        checkstr = "Weight";
    }
    //--------------------- Weight conversion code -------------------------------------------------------------------------
    public double weightFn(String in,String out,double v) {
        switch (in) {
            case "Grams":
                switch (out) {
                    case "Kilograms":
                        return v * 0.001;
                    case "Milligrams":
                        return v * 1000;
                    case "Pounds":
                        return v * 0.002205;
                    case "Ounces":
                        return v * 0.035274;
                    case "Tonne":
                        return v * 0.000001;
                }

            case "Kilograms":
                switch (out) {
                    case "Grams":
                        return v * 1000;
                    case "Pounds":
                        return v * 2.204623;
                    case "Milligrams":
                        return v * 1000000;
                    case "Ounces":
                        return v * 35.27396;
                    case "Tonne":
                        return v * 0.001;
                }

            case "Pounds":
                switch (out) {
                    case "Grams":
                        return v * 453.5924;
                    case "Kilograms":
                        return v * 0.453592;
                    case "Milligrams":
                        return v * 453592.4;
                    case "Ounces":
                        return v * 16;
                    case "Tonne":
                        return v * 0.000454;
                }

            case "Milligrams":
                switch (out) {
                    case "Grams":
                        return v * 0.001;
                    case "Kilograms":
                        return v * 0.000001;
                    case "Pounds":
                        return v * 0.000002;
                    case "Ounces":
                        return v * 0.000035;
                    case "Tonne":
                        return v * 0.000000001;
                }

            case "Ounces":
                switch (out) {
                    case "Grams":
                        return v * 28.34952;
                    case "Kilograms":
                        return v * 0.02835;
                    case "Milligrams":
                        return v * 28349.52;
                    case "Pounds":
                        return v * 0.0625;
                    case "Tonne":
                        return v * 0.000028;
                }
            case "Tonne":
                switch (out) {
                    case "Grams":
                        return v * 1000000;
                    case "Kilograms":
                        return v * 1000;
                    case "Milligrams":
                        return v * 1000000000;
                    case "Pounds":
                        return v * 2204.623;
                    case "Ounces":
                        return v * 35273.96;
                }
        }
        return 1;
    }
    //---------------------------------- Temp settings ---------------------------------------------------------------------
    public void tempWin(){
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Celsius", "Fahrenheit", "Kelvin"));
        cmb2.setItems(FXCollections.observableArrayList("Celsius", "Fahrenheit", "Kelvin"));
        checkstr = "Temp";
    }
    //----------------------------- Temp conversion code--------------------------------------------------------------------
    public double tempFn(String in,String out,double v) {
        switch (in) {
            case "Celsius":
                switch (out) {
                    case "Fahrenheit":
                        return v * 1.8 + 32;
                    case "Kelvin":
                        return v + 273.15;
                }
            case "Fahrenheit":
                switch (out) {
                    case "Celsius":
                        return ((v - 32) * 5) / 9;
                    case "Kelvin":
                        return ((v - 32) * 5) / 9 + 273.15;
                }
            case "Kelvin":
                switch (out) {
                    case "Fahrenheit":
                        return (v - 273.15) * 1.8 + 32;
                    case "Celsius":
                        return v - 273.15;
                }
        }
        return 1;
    }
    //-------------------------- Setting up for volume ---------------------------------------------------------------------
    public void volumeWin() {
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Litres","Millilitres","Cubic metres","Gallons","Cubic centimetres","Quarts"));
        cmb2.setItems(FXCollections.observableArrayList("Litres","Millilitres","Cubic metres","Gallons","Cubic centimetres","Quarts"));
        checkstr = "Volume";
    }
    //-------------------------- Vol conversion code -----------------------------------------------------------------------
    public double volumeFn(String in,String out,double v) {
        switch (in) {
            case "Litres":
                switch (out) {
                    case "Millilitres":
                        return v * 1000;
                    case "Cubic metres":
                        return v * 100;
                    case "Gallons":
                        return v * 0.000621;
                    case "Cubic centimetres":
                        return v * 0.001;
                    case "Quarts":
                        return v * 3.28084;
                }

            case "Millilitres":
                switch (out) {
                    case "Litres":
                        return v * 0.001;
                    case "Cubic metres":
                        return v * 0.1;
                    case "Gallons":
                        return v * 0.000000621371192;
                    case "Cubic centimetres":
                        return v * 0.000001;
                    case "Quarts":
                        return v * 0.003281;
                }

            case "Cubic metres":
                switch (out) {
                    case "Litres":
                        return v * 0.01;
                    case "Millilitres":
                        return v * 10;
                    case "Gallons":
                        return v * 0.000006;
                    case "Cubic centimetres":
                        return v * 0.00001;
                    case "Quarts":
                        return v * 0.032808;
                }

            case "Gallons":
                switch (out) {
                    case "Litres":
                        return v * 1609.344;
                    case "Millilitres":
                        return v * 1609344;
                    case "Cubic metres":
                        return v * 160934.4;
                    case "Cubic centimetres":
                        return v * 1.609344;
                    case "Quarts":
                        return v * 5280;
                }

            case "Cubic centimetres":
                switch (out) {
                    case "Litres":
                        return v * 1000;
                    case "Millilitres":
                        return v * 1000000;
                    case "Cubic metres":
                        return v * 100000;
                    case "Gallons":
                        return v * 0.621371;
                    case "Quarts":
                        return v * 3280.84;
                }
            case "Quarts":
                switch (out) {
                    case "Litres":
                        return v * 0.3048;
                    case "Millilitres":
                        return v * 304.8;
                    case "Cubic metres":
                        return v * 30.48;
                    case "Gallons":
                        return v * 0.000189;
                    case "Cubic centimetres":
                        return v * 0.000305;
                }
        }
        return 1;
    }
    //------------------------- Setting up for currency --------------------------------------------------------------------
    public void currencyWin() {
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Dollar","Euro","Rupee","Pound","Dirham"));
        cmb2.setItems(FXCollections.observableArrayList("Dollar","Euro","Rupee","Pound","Dirham"));
        checkstr = "Currency";
    }
    //------------------------- Currency conversion code -------------------------------------------------------------------
    public double currencyFn(String in,String out,double v) {
        switch (in) {
            case "Dollar":
                switch (out) {
                    case "Euro":
                        return v * 0.92;
                    case "Rupee":
                        return v * 83.17;
                    case "Pound":
                        return v * 0.81;
                    case "Dirham":
                        return v * 3.67;
                }
            case "Euro":
                switch (out) {
                    case "Dollar":
                        return v * 1.08;
                    case "Rupee":
                        return v * 90.24;
                    case "Pound":
                        return v * 0.87;
                    case "Dirham":
                        return v * 3.98;
                }
            case "Rupee":
                switch (out) {
                    case "Dollar":
                        return v * 0.012;
                    case "Euro":
                        return v * 0.011;
                    case "Pound":
                        return v * 0.0097;
                    case "Dirham":
                        return v * 0.044;
                }
            case "Pound":
                switch (out) {
                    case "Dollar":
                        return v * 1.24;
                    case "Euro":
                        return v * 1.14;
                    case "Rupee":
                        return v * 103.28;
                    case "Dirham":
                        return v * 4.56;
                }
            case "Dirham":
                switch (out) {
                    case "Dollar":
                        return v * 0.27;
                    case "Euro":
                        return v * 0.25;
                    case "Rupee":
                        return v * 22.64;
                    case "Pound":
                        return v * 0.22;
                }
        }
        return 1;
    }
    //----------------------------------- MathsFun -----------------------------------------------

    @FXML
    public void sWin(ActionEvent event) {
        try {
            ((Stage)(((Button)event.getSource()).getScene().getWindow())).setWidth(870);
            ((Stage)(((Button)event.getSource()).getScene().getWindow())).setHeight(615);
            Pane4.setVisible(true);
            Pane3.setVisible(false);
            Pane2.setVisible(false);
            Pane1.setVisible(false);
        } catch (Exception e) {
            System.out.println("Cant load");
        }
    }
    //-------------------------------------- Setting up for Num Sys ----------------------------------------------------
    public void numWin() {
        Pane3.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        cmb1.setPromptText("Select unit for input");
        cmb2.setPromptText("Select unit for output");
        cmb1.setItems(FXCollections.observableArrayList("Decimal","Binary","Octal","HexaDecimal"));
        cmb2.setItems(FXCollections.observableArrayList("Decimal","Binary","Octal","HexaDecimal"));
        checkstr = "NumSys";
    }
    //------------------------- NumSys conversion code -----------------------------------------------------------------
    public String numSys(String in, String out, int v) {
        switch (in) {
            case "Decimal":
                switch (out) {
                    case "Binary": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 10);
                        String binary = Integer.toBinaryString(num);
                        return binary;
                    }
                    case "Octal": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 10);
                        String octal = Integer.toOctalString(num);
                        return octal;
                    }
                    case "HexaDecimal": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 10);
                        String hexadecimal = Integer.toHexString(num);
                        return hexadecimal;
                    }
                }
            case "Octal": {
                switch (out) {
                    case "Binary": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 8);
                        String binary = Integer.toBinaryString(num);
                        return binary;
                    }
                    case "Decimal": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 8);
                        String decimal = Integer.toString(num);
                        return decimal;
                    }
                    case "Hexadecimal": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 8);
                        String hexadecimal = Integer.toHexString(num);
                        return hexadecimal;
                    }
                }
            }
            case "Binary": {
                switch (out) {
                    case "Octal": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 2);
                        String octal = Integer.toOctalString(num);
                        return octal;
                    }
                    case "Decimal": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 2);
                        String decimal = Integer.toString(num);
                        return decimal;
                    }
                    case "Hexadecimal": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 2);
                        String hexadecimal = Integer.toHexString(num);
                        return hexadecimal;
                    }
                }
            }
            case "Hexadecimal": {
                switch (out) {
                    case "Binary": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 16);
                        String binary = Integer.toBinaryString(num);
                        return binary;
                    }
                    case "Octal": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 16);
                        String octal = Integer.toOctalString(num);
                        return octal;
                    }
                    case "Decimal": {
                        String s = Integer.toString(v);
                        int num = Integer.parseInt(s, 16);
                        String decimal = Integer.toString(num);
                        return decimal;
                    }
                }
            }
        }
        return "Nothing";
    }
    //------------------- Settings for Stats---------------------------------------------------
    public void statsWin() {
        Pane5.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        checkstr = "Stats";
    }
    //---------------------Setting function for Statics--------------
    @FXML
    TextArea Tx1,Tx3;
    @FXML
    TextField Tx2,Tx4;
    int number,fs=0;
    int num[];
    @FXML
    public void funs(ActionEvent ev){
        Tx2.setText((Tx2.getText())+((Button)ev.getSource()).getText());
    }
    public void dels() {
        String s = Tx2.getText();
        Tx2.setText(s.substring(0, s.length() - 1));}
    public void lenClearS(){
        Tx2.setText("");
    }

    public void calstat()
    {
        int zx=Tx1.getText().indexOf("E");
    if(zx==0)
    {
        number = Integer.parseInt(Tx2.getText());
        num = new int[number];
        Tx1.setText("Please enter "+number+"\none by one");
        Tx2.setText("");
    }
    else if(Tx2.getText()!="")
    {
         num[fs]=Integer.parseInt(Tx2.getText());
         fs++;
         if(fs==(number-1))
         {
             Tx2.setText("Done");
             Tx1.setText("Please choose the required\noperation");

         }
         else
         Tx2.setText("");

    }
    }
    public void Mean()
    {   int i=0;
        double sum=0;
        for(i=0;i<number;i++);
        {
            sum=sum+num[i];
        }
        Tx3.setText("MEAN = ");
        Tx4.setText(""+(sum/number));
    }
    //--------------------- Settings for graph ---------------------------------------------------
    public void graphWin() {
        Pane7.setVisible(true);
        Pane2.setVisible(false);
        Pane1.setVisible(false);
        checkstr = "Graph";
    }

    //------------------------------------ General equal button code -------------------------------------------------------
    public void leq(){
        double Y2;
        String s1;
        double y1=Double.parseDouble(M1.getText());
        int ival=Integer.parseInt(M1.getText());
        switch (checkstr){
            case "Length":
                Y2=lengthFn(cmb1.getValue(),cmb2.getValue(),y1);
                M2.setText(""+Y2);
                break;
            case "Weight":
                Y2=weightFn(cmb1.getValue(),cmb2.getValue(),y1);
                M2.setText(""+Y2);
                break;
            case "Temp":
                Y2=tempFn(cmb1.getValue(),cmb2.getValue(),y1);
                M2.setText(""+Y2);
                break;
            case "Volume":
                Y2=volumeFn(cmb1.getValue(),cmb2.getValue(),y1);
                M2.setText(""+Y2);
                break;
            case "Currency":
                Y2=currencyFn(cmb1.getValue(),cmb2.getValue(),y1);
                M2.setText(""+Y2);
                break;
            case "NumSys":
                s1=numSys(cmb1.getValue(),cmb2.getValue(),ival);
                M2.setText(""+s1);
                break;

        }
    }
}

